# Keep JavaScript interface members if you add any (none by default).
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
